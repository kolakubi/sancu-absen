<h1 class="text-center">Selamat datang, Admin</h1>
<p class="text-center" style="font-size: 20px;">silakan pilih menu</p>

<div class="row">
    <div class="col-xs-4">
        <p class="text-center">
            <a href="<?php echo base_url() ?>admin/absen" style="color: transparent; display: block;">
                <img src="<?php echo base_url() ?>asset/image/user.png" class="img" style="margin: 0 auto">
            </a>
        </p>
        <p class="text-center" style="font-weight: bold">Laporan Absen</p>
    </div>
</div>