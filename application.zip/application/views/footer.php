<script src="<?php echo base_url() ?>asset/js/particle/particles.min.js"></script>
	<script type="text/javascript">
		particlesJS.load('particles-js', '<?php echo base_url() ?>asset/js/particle/particles.json', function() {
			console.log('callback - particles.js config loaded');
		});
	</script>

</body>
</html>